"use client";
import { useState } from "react";
import NavBar from "@/components/NavBar";

export default function LoginPage() {
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  function handleSubmit(e) {
    e.preventDefault();
    // TODO: wire to Supabase — POST /api/auth/login
    setError("Login isn't connected yet — this is a demo screen.");
  }

  return (
    <>
      <NavBar />
      <main className="flex-1 flex items-center justify-center px-4 py-16">
        <form
          onSubmit={handleSubmit}
          className="w-full max-w-sm bg-pitch-card border border-white/10 rounded-lg p-6"
        >
          <h1 className="font-display text-2xl mb-1">Log in</h1>
          <p className="text-chalk-dim text-sm mb-6">
            Use the phone number you signed up with.
          </p>

          <label className="block text-sm mb-1.5 text-chalk-dim">
            Phone number
          </label>
          <input
            type="tel"
            required
            placeholder="07XXXXXXXX"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="w-full mb-4 bg-pitch border border-white/15 rounded-md px-3 py-2.5 outline-none focus:border-floodlight"
          />

          <label className="block text-sm mb-1.5 text-chalk-dim">
            Password
          </label>
          <input
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full mb-5 bg-pitch border border-white/15 rounded-md px-3 py-2.5 outline-none focus:border-floodlight"
          />

          {error && (
            <p className="text-loss text-sm mb-4">{error}</p>
          )}

          <button
            type="submit"
            className="w-full bg-floodlight text-pitch font-display tracking-wide py-2.5 rounded-md hover:brightness-110"
          >
            Log In
          </button>

          <p className="text-chalk-dim text-sm mt-4 text-center">
            No account?{" "}
            <a href="/signup" className="text-floodlight">
              Sign up
            </a>
          </p>
        </form>
      </main>
    </>
  );
}
