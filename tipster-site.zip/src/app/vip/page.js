"use client";
import { useState } from "react";
import NavBar from "@/components/NavBar";
import { mockPackages } from "@/lib/mockData";

function formatUGX(n) {
  return "UGX " + n.toLocaleString("en-UG");
}

export default function VipPage() {
  const [selected, setSelected] = useState(mockPackages[1].id);
  const [showPayModal, setShowPayModal] = useState(false);

  return (
    <>
      <NavBar />
      <main className="flex-1 max-w-3xl mx-auto px-4 sm:px-6 py-14 w-full">
        <p className="font-display text-floodlight tracking-widest text-xs uppercase mb-2">
          VIP Access
        </p>
        <h1 className="font-display text-3xl sm:text-4xl mb-2">
          Pick your package
        </h1>
        <p className="text-chalk-dim mb-8">
          Pay with MTN Mobile Money or Airtel Money. VIP unlocks instantly
          after payment is confirmed.
        </p>

        <div className="grid sm:grid-cols-3 gap-4 mb-8">
          {mockPackages.map((pkg) => (
            <button
              key={pkg.id}
              onClick={() => setSelected(pkg.id)}
              className={`text-left rounded-lg border p-5 transition ${
                selected === pkg.id
                  ? "border-floodlight bg-floodlight/10"
                  : "border-white/10 bg-pitch-card hover:border-white/25"
              }`}
            >
              <div className="text-chalk-dim text-sm">{pkg.name}</div>
              <div className="font-display text-2xl mt-1">
                {formatUGX(pkg.price_ugx)}
              </div>
              <div className="text-chalk-dim text-xs mt-1">
                {pkg.duration_days} day{pkg.duration_days > 1 ? "s" : ""} access
              </div>
            </button>
          ))}
        </div>

        <button
          onClick={() => setShowPayModal(true)}
          className="w-full sm:w-auto bg-floodlight text-pitch font-display tracking-wide px-6 py-3 rounded-md hover:brightness-110"
        >
          Pay VIP
        </button>

        {showPayModal && (
          <div className="fixed inset-0 bg-black/60 flex items-center justify-center px-4 z-30">
            <div className="bg-pitch-card border border-white/10 rounded-lg p-6 max-w-sm w-full">
              <h2 className="font-display text-xl mb-2">Payment</h2>
              <p className="text-chalk-dim text-sm mb-4">
                MTN &amp; Airtel Mobile Money checkout isn&apos;t wired up
                yet — this is a placeholder for the demo. Real flow:
                enter number, confirm on phone, VIP unlocks on approval.
              </p>
              <button
                onClick={() => setShowPayModal(false)}
                className="w-full bg-chalk text-pitch py-2.5 rounded-md font-medium"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </main>
    </>
  );
}
