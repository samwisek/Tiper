"use client";
import { useState } from "react";
import {
  mockTips,
  mockPackages,
  mockAnnouncements,
  mockAds,
} from "@/lib/mockData";

const TABS = ["Tips", "Packages", "Announcements", "Adverts", "Payments"];

export default function AdminPage() {
  const [tab, setTab] = useState("Tips");
  const [tips, setTips] = useState(mockTips);
  const [packages, setPackages] = useState(mockPackages);
  const [announcements, setAnnouncements] = useState(mockAnnouncements);
  const [ads, setAds] = useState(mockAds);

  return (
    <div className="flex-1 min-h-screen bg-pitch text-chalk">
      <header className="border-b border-white/10 px-4 sm:px-6 h-16 flex items-center justify-between">
        <span className="font-display text-xl">
          TIPS<span className="text-floodlight">HQ</span>{" "}
          <span className="text-chalk-dim text-sm font-body">Admin</span>
        </span>
        <a href="/" className="text-chalk-dim text-sm hover:text-chalk">
          View site &rarr;
        </a>
      </header>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex gap-1 mb-8 border-b border-white/10 overflow-x-auto">
          {TABS.map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`px-4 py-2.5 text-sm font-medium whitespace-nowrap border-b-2 -mb-px ${
                tab === t
                  ? "border-floodlight text-chalk"
                  : "border-transparent text-chalk-dim hover:text-chalk"
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        {tab === "Tips" && <TipsTab tips={tips} setTips={setTips} />}
        {tab === "Packages" && (
          <PackagesTab packages={packages} setPackages={setPackages} />
        )}
        {tab === "Announcements" && (
          <AnnouncementsTab
            announcements={announcements}
            setAnnouncements={setAnnouncements}
          />
        )}
        {tab === "Adverts" && <AdsTab ads={ads} setAds={setAds} />}
        {tab === "Payments" && <PaymentsTab />}
      </div>
    </div>
  );
}

/* ---------- shared bits ---------- */
function Card({ children }) {
  return (
    <div className="bg-pitch-card border border-white/10 rounded-lg p-4">
      {children}
    </div>
  );
}
function Input(props) {
  return (
    <input
      {...props}
      className="w-full bg-pitch border border-white/15 rounded-md px-3 py-2 outline-none focus:border-floodlight text-sm"
    />
  );
}
function AddButton(props) {
  return (
    <button
      {...props}
      className="bg-floodlight text-pitch font-medium text-sm px-4 py-2 rounded-md hover:brightness-110"
    />
  );
}

/* ---------- Tips ---------- */
function TipsTab({ tips, setTips }) {
  const [form, setForm] = useState({
    league: "",
    home_team: "",
    away_team: "",
    market: "",
    odds: "",
    confidence: "Medium",
    kickoff_time: "",
    is_vip: false,
  });

  function addTip(e) {
    e.preventDefault();
    if (!form.home_team || !form.away_team) return;
    setTips([{ ...form, id: Date.now(), result: "pending" }, ...tips]);
    setForm({
      league: "",
      home_team: "",
      away_team: "",
      market: "",
      odds: "",
      confidence: "Medium",
      kickoff_time: "",
      is_vip: false,
    });
  }

  function removeTip(id) {
    setTips(tips.filter((t) => t.id !== id));
  }

  return (
    <div className="grid lg:grid-cols-[1fr_1.3fr] gap-6">
      <Card>
        <h2 className="font-display text-lg mb-4">Post a tip</h2>
        <form onSubmit={addTip} className="space-y-3">
          <Input
            placeholder="League (e.g. EPL)"
            value={form.league}
            onChange={(e) => setForm({ ...form, league: e.target.value })}
          />
          <div className="grid grid-cols-2 gap-3">
            <Input
              placeholder="Home team"
              value={form.home_team}
              onChange={(e) =>
                setForm({ ...form, home_team: e.target.value })
              }
            />
            <Input
              placeholder="Away team"
              value={form.away_team}
              onChange={(e) =>
                setForm({ ...form, away_team: e.target.value })
              }
            />
          </div>
          <Input
            placeholder="Market / pick (e.g. Over 2.5)"
            value={form.market}
            onChange={(e) => setForm({ ...form, market: e.target.value })}
          />
          <div className="grid grid-cols-2 gap-3">
            <Input
              placeholder="Odds"
              value={form.odds}
              onChange={(e) => setForm({ ...form, odds: e.target.value })}
            />
            <select
              value={form.confidence}
              onChange={(e) =>
                setForm({ ...form, confidence: e.target.value })
              }
              className="bg-pitch border border-white/15 rounded-md px-3 py-2 text-sm outline-none focus:border-floodlight"
            >
              <option>High</option>
              <option>Medium</option>
              <option>Low</option>
            </select>
          </div>
          <Input
            type="datetime-local"
            value={form.kickoff_time}
            onChange={(e) =>
              setForm({ ...form, kickoff_time: e.target.value })
            }
          />
          <label className="flex items-center gap-2 text-sm text-chalk-dim">
            <input
              type="checkbox"
              checked={form.is_vip}
              onChange={(e) =>
                setForm({ ...form, is_vip: e.target.checked })
              }
            />
            VIP only
          </label>
          <AddButton type="submit">Post tip</AddButton>
        </form>
      </Card>

      <div className="space-y-3">
        {tips.map((t) => (
          <div
            key={t.id}
            className="bg-pitch-card border border-white/10 rounded-lg p-4 flex items-start justify-between gap-3"
          >
            <div>
              <div className="text-xs text-chalk-dim uppercase tracking-wide">
                {t.league || "—"} {t.is_vip && (
                  <span className="text-floodlight ml-2">VIP</span>
                )}
              </div>
              <div className="font-display">
                {t.home_team} vs {t.away_team}
              </div>
              <div className="text-sm text-chalk-dim">
                {t.market} @ {t.odds}
              </div>
            </div>
            <button
              onClick={() => removeTip(t.id)}
              className="text-loss text-sm shrink-0"
            >
              Remove
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------- Packages ---------- */
function PackagesTab({ packages, setPackages }) {
  const [form, setForm] = useState({ name: "", price_ugx: "", duration_days: "" });

  function addPackage(e) {
    e.preventDefault();
    if (!form.name || !form.price_ugx) return;
    setPackages([
      ...packages,
      {
        id: Date.now(),
        name: form.name,
        price_ugx: Number(form.price_ugx),
        duration_days: Number(form.duration_days) || 1,
      },
    ]);
    setForm({ name: "", price_ugx: "", duration_days: "" });
  }

  function removePackage(id) {
    setPackages(packages.filter((p) => p.id !== id));
  }

  return (
    <div className="grid lg:grid-cols-[1fr_1.3fr] gap-6">
      <Card>
        <h2 className="font-display text-lg mb-4">Add VIP package</h2>
        <form onSubmit={addPackage} className="space-y-3">
          <Input
            placeholder="Package name (e.g. Weekly VIP)"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
          />
          <Input
            placeholder="Price (UGX)"
            type="number"
            value={form.price_ugx}
            onChange={(e) => setForm({ ...form, price_ugx: e.target.value })}
          />
          <Input
            placeholder="Duration (days)"
            type="number"
            value={form.duration_days}
            onChange={(e) =>
              setForm({ ...form, duration_days: e.target.value })
            }
          />
          <AddButton type="submit">Add package</AddButton>
        </form>
      </Card>
      <div className="space-y-3">
        {packages.map((p) => (
          <div
            key={p.id}
            className="bg-pitch-card border border-white/10 rounded-lg p-4 flex items-center justify-between"
          >
            <div>
              <div className="font-display">{p.name}</div>
              <div className="text-sm text-chalk-dim">
                UGX {p.price_ugx.toLocaleString()} &middot; {p.duration_days} day
                {p.duration_days > 1 ? "s" : ""}
              </div>
            </div>
            <button
              onClick={() => removePackage(p.id)}
              className="text-loss text-sm"
            >
              Remove
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------- Announcements ---------- */
function AnnouncementsTab({ announcements, setAnnouncements }) {
  const [form, setForm] = useState({ title: "", message: "" });

  function addAnnouncement(e) {
    e.preventDefault();
    if (!form.message) return;
    setAnnouncements([
      { id: Date.now(), ...form, created_at: new Date().toISOString() },
      ...announcements,
    ]);
    setForm({ title: "", message: "" });
  }

  function remove(id) {
    setAnnouncements(announcements.filter((a) => a.id !== id));
  }

  return (
    <div className="grid lg:grid-cols-[1fr_1.3fr] gap-6">
      <Card>
        <h2 className="font-display text-lg mb-4">Post announcement</h2>
        <form onSubmit={addAnnouncement} className="space-y-3">
          <Input
            placeholder="Title (optional)"
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
          />
          <textarea
            placeholder="Message"
            value={form.message}
            onChange={(e) => setForm({ ...form, message: e.target.value })}
            rows={4}
            className="w-full bg-pitch border border-white/15 rounded-md px-3 py-2 outline-none focus:border-floodlight text-sm"
          />
          <AddButton type="submit">Post</AddButton>
        </form>
      </Card>
      <div className="space-y-3">
        {announcements.map((a) => (
          <div
            key={a.id}
            className="bg-pitch-card border border-white/10 rounded-lg p-4 flex items-start justify-between gap-3"
          >
            <div>
              {a.title && <div className="font-display">{a.title}</div>}
              <div className="text-sm text-chalk-dim">{a.message}</div>
            </div>
            <button onClick={() => remove(a.id)} className="text-loss text-sm shrink-0">
              Remove
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------- Ads ---------- */
function AdsTab({ ads, setAds }) {
  const [form, setForm] = useState({ title: "", link_url: "" });

  function addAd(e) {
    e.preventDefault();
    if (!form.title) return;
    setAds([...ads, { id: Date.now(), ...form, image_url: "", active: true }]);
    setForm({ title: "", link_url: "" });
  }

  function toggle(id) {
    setAds(ads.map((a) => (a.id === id ? { ...a, active: !a.active } : a)));
  }
  function remove(id) {
    setAds(ads.filter((a) => a.id !== id));
  }

  return (
    <div className="grid lg:grid-cols-[1fr_1.3fr] gap-6">
      <Card>
        <h2 className="font-display text-lg mb-4">Add advert</h2>
        <form onSubmit={addAd} className="space-y-3">
          <Input
            placeholder="Advert title"
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
          />
          <Input
            placeholder="Link URL"
            value={form.link_url}
            onChange={(e) => setForm({ ...form, link_url: e.target.value })}
          />
          <p className="text-xs text-chalk-dim">
            Image upload will connect once Supabase storage is wired in.
          </p>
          <AddButton type="submit">Add advert</AddButton>
        </form>
      </Card>
      <div className="space-y-3">
        {ads.map((a) => (
          <div
            key={a.id}
            className="bg-pitch-card border border-white/10 rounded-lg p-4 flex items-center justify-between gap-3"
          >
            <div>
              <div className="font-display">{a.title}</div>
              <div className="text-sm text-chalk-dim">
                {a.active ? "Active" : "Paused"}
              </div>
            </div>
            <div className="flex gap-3 shrink-0">
              <button onClick={() => toggle(a.id)} className="text-floodlight text-sm">
                {a.active ? "Pause" : "Activate"}
              </button>
              <button onClick={() => remove(a.id)} className="text-loss text-sm">
                Remove
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------- Payments ---------- */
function PaymentsTab() {
  return (
    <Card>
      <h2 className="font-display text-lg mb-2">VIP Payments</h2>
      <p className="text-chalk-dim text-sm">
        Not connected yet. Once wired up, MTN and Airtel Mobile Money
        submissions will land here for you to approve or reject — approving
        activates the user&apos;s VIP package automatically.
      </p>
    </Card>
  );
}
