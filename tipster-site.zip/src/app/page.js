import NavBar from "@/components/NavBar";
import TipTicket from "@/components/TipTicket";
import { mockTips, mockAnnouncements, mockAds } from "@/lib/mockData";
import Link from "next/link";

export default function Home() {
  const freeTips = mockTips.filter((t) => !t.is_vip);
  const vipTips = mockTips.filter((t) => t.is_vip);

  return (
    <>
      <NavBar />
      <main className="flex-1">
        {/* Hero */}
        <section className="border-b border-white/10">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 py-14 sm:py-20">
            <p className="font-display text-floodlight tracking-widest text-xs sm:text-sm uppercase mb-3">
              Kick-off in a few hours &middot; Today&apos;s slate is live
            </p>
            <h1 className="font-display text-4xl sm:text-6xl leading-[1.05] max-w-2xl">
              Tips that get you off the bench.
            </h1>
            <p className="text-chalk-dim mt-4 max-w-md">
              Hand-picked football predictions, posted daily. Free picks for
              everyone, sharper odds and accumulators for VIP.
            </p>
            <div className="flex flex-wrap gap-3 mt-7">
              <Link
                href="/vip"
                className="bg-floodlight text-pitch px-5 py-2.5 rounded-md font-display tracking-wide hover:brightness-110"
              >
                Unlock VIP Tips
              </Link>
              <a
                href="#free-tips"
                className="border border-white/20 px-5 py-2.5 rounded-md font-display tracking-wide hover:bg-white/5"
              >
                See Free Tips
              </a>
            </div>
          </div>
        </section>

        {/* Announcements */}
        {mockAnnouncements.length > 0 && (
          <section className="max-w-5xl mx-auto px-4 sm:px-6 pt-8">
            {mockAnnouncements.map((a) => (
              <div
                key={a.id}
                className="bg-floodlight/10 border border-floodlight/30 rounded-md px-4 py-3 text-sm flex gap-3"
              >
                <span className="text-floodlight font-display shrink-0">
                  Announcement
                </span>
                <span className="text-chalk-dim">{a.message}</span>
              </div>
            ))}
          </section>
        )}

        {/* Free tips */}
        <section id="free-tips" className="max-w-5xl mx-auto px-4 sm:px-6 py-12">
          <div className="flex items-baseline justify-between mb-5">
            <h2 className="font-display text-2xl tracking-tight">
              Today&apos;s Free Tips
            </h2>
            <span className="text-chalk-dim text-sm">
              {freeTips.length} match{freeTips.length !== 1 ? "es" : ""}
            </span>
          </div>
          <div className="grid gap-4">
            {freeTips.map((tip) => (
              <TipTicket key={tip.id} tip={tip} />
            ))}
          </div>
        </section>

        {/* VIP teaser */}
        <section className="max-w-5xl mx-auto px-4 sm:px-6 pb-16">
          <div className="flex items-baseline justify-between mb-5">
            <h2 className="font-display text-2xl tracking-tight">
              VIP Tips
            </h2>
            <Link href="/vip" className="text-floodlight text-sm font-medium">
              Unlock &rarr;
            </Link>
          </div>
          <div className="grid gap-4">
            {vipTips.map((tip) => (
              <TipTicket key={tip.id} tip={tip} locked />
            ))}
          </div>
        </section>

        {/* Ads */}
        {mockAds.filter((a) => a.active).length > 0 && (
          <section className="max-w-5xl mx-auto px-4 sm:px-6 pb-16">
            <div className="border border-dashed border-white/15 rounded-md p-6 text-center text-chalk-dim text-sm">
              Advert space &mdash; {mockAds[0].title}
            </div>
          </section>
        )}
      </main>

      <footer className="border-t border-white/10 py-8 text-center text-xs text-chalk-dim">
        18+ Bet responsibly. TipsHQ tips are informational, not guarantees.
      </footer>
    </>
  );
}
