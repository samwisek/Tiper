import Link from "next/link";

export default function NavBar() {
  return (
    <header className="border-b border-white/10 bg-pitch/95 backdrop-blur sticky top-0 z-20">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        <Link href="/" className="font-display text-xl tracking-tight">
          TIPS<span className="text-floodlight">HQ</span>
        </Link>
        <nav className="flex items-center gap-4 sm:gap-6 text-sm">
          <Link href="/vip" className="text-floodlight font-medium">
            Go VIP
          </Link>
          <Link href="/login" className="text-chalk-dim hover:text-chalk">
            Log in
          </Link>
          <Link
            href="/signup"
            className="bg-chalk text-pitch px-3 py-1.5 rounded-md font-medium hover:bg-white"
          >
            Sign up
          </Link>
        </nav>
      </div>
    </header>
  );
}
