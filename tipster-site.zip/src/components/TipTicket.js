const confidenceColor = {
  High: "text-win",
  Medium: "text-floodlight",
  Low: "text-chalk-dim",
};

export default function TipTicket({ tip, locked = false }) {
  const kickoff = new Date(tip.kickoff_time);
  const time = kickoff.toLocaleString("en-UG", {
    weekday: "short",
    hour: "2-digit",
    minute: "2-digit",
  });

  return (
    <div className="ticket flex items-stretch bg-pitch-card border border-white/10 rounded-r-lg rounded-l-sm overflow-hidden pl-5">
      <div className="flex-1 p-4">
        <div className="flex items-center justify-between text-xs uppercase tracking-wider text-chalk-dim mb-2">
          <span>{tip.league}</span>
          <span>{time}</span>
        </div>
        <div className="font-display text-lg sm:text-xl tracking-tight">
          {tip.home_team} <span className="text-chalk-dim">vs</span>{" "}
          {tip.away_team}
        </div>

        {locked ? (
          <div className="mt-3 flex items-center gap-2 text-chalk-dim text-sm">
            <LockIcon />
            VIP tip &mdash; unlock to view pick &amp; odds
          </div>
        ) : (
          <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm">
            <span className="text-chalk-dim">
              Pick: <span className="text-chalk font-medium">{tip.market}</span>
            </span>
            <span className={`font-medium ${confidenceColor[tip.confidence]}`}>
              {tip.confidence} confidence
            </span>
          </div>
        )}
      </div>

      <div className="w-24 sm:w-28 shrink-0 border-l border-dashed border-white/15 flex flex-col items-center justify-center bg-white/5">
        {locked ? (
          <LockIcon className="w-5 h-5 text-chalk-dim" />
        ) : (
          <>
            <span className="text-[10px] uppercase tracking-wider text-chalk-dim">
              Odds
            </span>
            <span className="font-display text-2xl text-floodlight">
              {tip.odds}
            </span>
          </>
        )}
      </div>
    </div>
  );
}

function LockIcon({ className = "w-4 h-4" }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" className={className}>
      <rect
        x="5"
        y="11"
        width="14"
        height="9"
        rx="1.5"
        stroke="currentColor"
        strokeWidth="1.6"
      />
      <path
        d="M8 11V8a4 4 0 018 0v3"
        stroke="currentColor"
        strokeWidth="1.6"
      />
    </svg>
  );
}
